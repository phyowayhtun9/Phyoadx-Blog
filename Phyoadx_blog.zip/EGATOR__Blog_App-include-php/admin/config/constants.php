<?php
session_start();
define('ROOT_URL', 'http://localhost:8888/blog_app/');
define('DB_HOST', 'localhost');
define('DB_USER', 'rick');
define('DB_PW', '123456');
define('DB_NAME', 'blog');
