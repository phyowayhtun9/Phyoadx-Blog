<?php include 'partials/header.php' ?>

<section class="empty__page">
	<h1>Contact</h1>
</section>

<?php include 'partials/footer.php';
